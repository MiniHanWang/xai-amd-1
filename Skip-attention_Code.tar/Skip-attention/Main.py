# 调用实际例子
from PIL import Image

from CAM_layer import mCAM
from Skip_VGG16 import VGG16
from tqdm import tqdm
import torch


Model = VGG16(8)
Model.load_state_dict(torch.load("Model/oct_model.pt"))  # 载入已有的模型并切换预测模式
# print(Model)
# print(type(Model.feature))
layerTag = [Model.feature[3], Model.feature[7], Model.feature[10], Model.feature[14], Model.feature[17],
            Model.feature[20],
            Model.feature[24], Model.feature[27], Model.feature[30], Model.feature[34], Model.feature[37],
            Model.feature[40], Model.feature[43]]  # 需要检测的层
layername = []
for i in range(0, 13):
    str1 = 'Conc2d-{}'.format(i)
    layername.append(str1)
with open('data/oct/oct_labelval.txt') as f:
    sum1 = sum([1 for i in open("data/oct/oct_labelval.txt", "r")])
    for idx, line in tqdm(enumerate(f), total=sum1):
        filename, label = line.split()
        mCAM('oct-layer', Model, filename, 0, layerTag, layername, False, layertitle=False)
