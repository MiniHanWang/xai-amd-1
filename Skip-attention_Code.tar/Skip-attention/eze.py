# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
"""
@Time ： 2023/2/8 17:26
@Auth ： Mini Han Wang
@File ：eze.py
@IDE ：PyCharm
@Motto:Mini
"""

import re
import pandas as pd
def go(csv_save_path, result_save_path):
	f = open(csv_save_path, 'r')
	for line in f:
		namelist = []
		vgg = []
		a = re.split(r",", line)
		b = a[2].replace('\n', '')
		namelist.append(a[1])
		vgg.append((b))
		print(namelist)
		print(vgg)
		FFA={'Filename':namelist,
	         'VGG16':vgg}
		FFACSV=pd.DataFrame.from_dict(FFA,orient='index').transpose()
		FFACSV.to_csv(result_save_path+a[1]+'.csv')