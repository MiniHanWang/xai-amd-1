import math
import torch
from torch import nn, optim
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
import sys
import os
import PIL
from PIL import Image
import pandas as pd
import torch.nn.functional as F

import csv
class SkipConnection(nn.Module):
    def __init__(self, in_features, out_features, mode='add'):
        super(SkipConnection, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.mode = mode  # add or concatenate

        # fix The Code And Implement The Self FfnnMethod
        self.ffnn = nn.Sequential(
            nn.Conv2d(in_features, out_features, kernel_size=1),
            nn.BatchNorm2d(out_features)
        )

    def forward(self, input):
        if self.in_features == self.out_features:
            if self.mode == 'add':
                return input + self.ffnn(input)  #call The SelfFfnn Method
            elif self.mode == 'concatenate':
                return torch.cat((input, self.ffnn(input)), dim=-1)
        else:
            return self.ffnn(input)


class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction, in_channels),
            nn.ReLU(inplace=True)  # use ReLU Alternative Sigmoid
        )

        self.excitation = nn.Conv2d(in_channels, in_channels, 1, 1, 0)

    def forward(self, x):
        b, c, _, _ = x.size()
        # scale=1
        x_se = x
        ...

        y = self.avg_pool(x_se).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        # scaleexcit()
        z = torch.mul(y, x)
        return z


class VGG16(nn.Module):
    def __init__(self, num_classes):
        super(VGG16, self).__init__()
        self.feature = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),

            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),

            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),

            nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),

            nn.Conv2d(in_channels=256, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            SEBlock(512, 16),
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            SEBlock(512, 16),
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            SEBlock(512, 16),
            nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
        )

        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, num_classes)
        )
        self._initialize_weights()

    def forward(self, x):
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        x = x.to(device)
        x2 = self.feature[0:35](x)
        x3 = self.feature[0:38](x)
        x4 = self.feature[0:46](x)
        mconv = nn.Conv2d(in_channels=512, out_channels=512, kernel_size=3, stride=2, padding=1).to(device)
        outputsize = self.feature(x).size()
        x2 = nn.Conv2d(512, 512, 3, stride=2, padding=1).to(device)(x2)
        skipX = mconv(x2 + x3 + x4)
        x = self.feature(x) + skipX
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()



def transforms_RandomHorizontalFlip(path_train, path_test):
    transforms_train = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])

    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    train_dataset = datasets.ImageFolder(root=path_train, transform=transforms_train)
    test_dataset = datasets.ImageFolder(root=path_test, transform=transform)
    return train_dataset, test_dataset




def go(path_train, path_test, path_save_model):
    image_size = (224, 224)  #
    data_transforms = transforms.Compose([
        transforms.RandomHorizontalFlip(), 
        transforms.Resize(image_size),  
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),  

    ])

    train_data = datasets.ImageFolder(root=path_train, transform=data_transforms)  


    model = VGG16(8)
    # print(model)

    epoch_num = 100
    batch_size = 8
    num_print = 5
    lr = 0.001
    step_size = 4
    baseAcc = 59.5

    optimiter = optim.SGD(model.parameters(), lr=lr, momentum=0.8, weight_decay=0.001)
    schedule = optim.lr_scheduler.StepLR(optimiter, step_size=step_size, gamma=0.5, last_epoch=-1)
    train_dataset, test_dataset = transforms_RandomHorizontalFlip(path_train, path_test)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    criterion = nn.CrossEntropyLoss()
    loss_list = []
    # device = torch.device("mps")
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')  
    print(device)
    model.load_state_dict(torch.load('D:\Project\ExplainableDL\Skip-attention\Model\RCPF-sem_skip_{}.pt'.format(baseAcc)))
    model.to(device)
    model.train()
    print('model Initialization........\n')
   
    for epoch in range(epoch_num):
        Loss = 0.0
        model.train()
        for i, (inputs, labels) in enumerate(train_loader):
            inputs = inputs.to(device)
            labels = labels.to(device)
            optimiter.zero_grad()
            outputs = model(inputs)

            loss = criterion(outputs, labels)
            loss.backward()
            optimiter.step()

            Loss += loss.item()
            loss_list.append(loss.item())
            print('\r', end='')
            print('Epoch:{} Progress:{:.0f}%'.format(epoch, (i+1)*4 / 400 * 100), '▋' * (i // 2), end='')
            sys.stdout.flush()
        #         time.sleep(0.05)
        print(' loss:%.3f' % (Loss / num_print),end=' ')
        Loss = 0.0

        model.eval()
        correct = 0.0
        total = 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                pred = outputs.argmax(dim=1)
                total += inputs.size(0)
                correct += torch.eq(pred, labels).sum().item()
        tACC = 100 * correct / total
        print("Accuracy: %.2f %%" % (tACC))
        if tACC > baseAcc:
            torch.save(model.state_dict(), path_save_model.format(100 * correct / total))
            baseAcc = 100 * correct / total
            print("\nsave The Optimal Model· Accuracy: %.2f %%" % (100 * correct / total))
            if tACC > 98:
                break




def wend (dataset, model, test_image_name, a ):
    batch_size = 32
    image_transform = {
            'test':transforms.Compose ( [
                transforms.Resize ( (224, 224) ),
                transforms.ToTensor ( ),
                transforms.Normalize ( mean = [ 0.485, 0.456, 0.406 ], std = [ 0.229, 0.224, 0.225 ] ),
            ] )
        }
    dataset1 = dataset
    test_directory = os.path.join ( dataset1, 'test-resize' )
    data = {
        'test':datasets.ImageFolder ( root = test_directory, transform = image_transform [ 'test' ] )
    }
    test_data_size = len ( data [ 'test' ] )
    test_data = DataLoader ( data [ 'test' ], batch_size = batch_size, shuffle = True )
    idx_to_class = { v:k for k, v in data [ 'test' ].class_to_idx.items ( ) }

    # loss_func = nn.NLLLoss ( )
    transform = image_transform [ 'test' ]
    test_image = PIL.Image.open ( test_image_name ).convert ( 'RGB' )
    draw = PIL.ImageDraw.Draw ( test_image )
    test_image_tensor = transform ( test_image )
    test_image_tensor = test_image_tensor.view ( 1, 3, 224, 224 )
    classes = [ ]
    max_class = [ ]
    with torch.no_grad ( ):
        out = model ( test_image_tensor )
        for i in idx_to_class.keys ( ):
            classes.append ( idx_to_class [ i ] )
        _, indices = torch.sort ( out, descending = True )
        percentage = torch.nn.functional.softmax ( out, dim = 1 ) [ 0 ] * 100
        for i in range ( 0, 2 ):
            max_class.append ( str ( percentage [ i ].item ( ) ) )
            if classes [ max_class.index ( max ( max_class ) ) ] == 'normal':
                classes [ max_class.index ( max ( max_class ) ) ] = 0
            if classes [ max_class.index ( max ( max_class ) ) ] == 'drusen':
                classes [ max_class.index ( max ( max_class ) ) ] = 1
        return test_image_name, classes [ max_class.index ( max ( max_class ) ) ]




def baocun(dataset, path_val, csv_save_path):
    model = VGG16 ( 8 )
    p = os.listdir ( path_val )
    FN = [ ]
    Pd = [ ]
    for i in range ( len ( p ) ):
        # img = predict ( model, './roi/val/' + p [ i ], i )
        # img = img.save ( './roiModel/predict_vgg16/' + p [ i ] )
        en = wend (dataset, model, path_val + p [ i ], i )
        a = en [ 0 ]
        b = en [ 1 ]
        name = a.replace ( path_val, '' )
        FN.append ( name )
        Pd.append ( b )
        data = { 'FileName':FN,
                 'Predict':Pd }
        text = pd.DataFrame.from_dict ( data, orient = 'index' ).transpose ( )
    text.to_csv ( csv_save_path )

