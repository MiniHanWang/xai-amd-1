import SkipStructure
import eze

path_train = r'D:\Project\ExplainableDL\Skip-attention\data\RCPF\train-resize'
path_test = r'D:\Project\ExplainableDL\Skip-attention\data\RCPF/test-resize/'
path_save_model = r'D:\Project\ExplainableDL\Skip-attention\Model/RCPF-sem_skip_{}.pt'
path_val = r'D:\Project\ExplainableDL\Skip-attention\data\RCPF\val/'
csv_save_path = r'D:\Project\ExplainableDL\Skip-attention\Model/skip_oct-RCPF.csv'
result_save_path = r'D:\Project\ExplainableDL\Skip-attention\result/skip-re/'
dataset = 'D:\Project\ExplainableDL\Skip-attention\data\RCPF/'

SkipStructure.go(path_train, path_test, path_save_model)
# SkipStructure.baocun(dataset, path_val, csv_save_path)
# eze.go(csv_save_path, result_save_path)
